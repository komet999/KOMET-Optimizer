#!/bin/bash
# MR KOMET v3.1 - Kali Linux Setup
# Complete installation and configuration

set -e

echo "╔════════════════════════════════════════════════════════════╗"
echo "║        MR KOMET v3.1 - Kali Linux Installation            ║"
echo "║        Complete Multi-Platform Account Removal System      ║"
echo "╚════════════════════════════════════════════════════════════╝"

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "[!] This script should be run as root (use sudo)"
    exit 1
fi

# Detect Python version
PYTHON_VERSION=$(python3 --version 2>&1 | awk '{print $2}' | cut -d. -f1,2)
if [ "$PYTHON_VERSION" \< "3.8" ]; then
    echo "[!] Python 3.8+ required. Found: $PYTHON_VERSION"
    exit 1
fi

echo "[*] Detected Python: $PYTHON_VERSION"

# Update system
echo "[*] Updating system packages..."
apt-get update -qq
apt-get install -y -qq curl wget git build-essential libssl-dev libffi-dev python3-dev

# Create directories
echo "[*] Creating directory structure..."
mkdir -p {data/accounts,data/proxies,data/fingerprints,data/reports,sessions,logs}
chmod 755 {data,sessions,logs}
chmod 600 data/accounts data/proxies

# Install Python dependencies
echo "[*] Installing Python dependencies..."
pip3 install --upgrade pip setuptools wheel --quiet
pip3 install -r requirements.txt --quiet

# Install optional dependencies for enhanced functionality
echo "[*] Installing optional enhancements..."
pip3 install playwright --quiet 2>/dev/null || true
pip3 install torch torchvision --quiet 2>/dev/null || true

# Create sample config
echo "[*] Creating sample configuration..."
cat > operation_example.json << 'EOF'
{
  "platform": "instagram",
  "target_name": "target_username",
  "report_type": "impersonation",
  "report_count": 100,
  "threads": 50,
  "max_concurrent": 100,
  "delay_min": 1.0,
  "delay_max": 5.0,
  "exponential_backoff": true,
  "circuit_breaker_enabled": true,
  "fingerprint_per_thread": true,
  "proxy_rotation_strategy": "random",
  "ai_report_generation": true,
  "detect_evasion_level": 3,
  "request_signature": true,
  "account_file": "data/accounts/accounts.json",
  "proxy_file": "data/proxies/working.txt"
}
EOF

# Create sample accounts file
echo "[*] Creating sample accounts file..."
mkdir -p data/accounts
cat > data/accounts/accounts.json << 'EOF'
[
  {
    "platform": "instagram",
    "username": "your_username",
    "password": "your_password",
    "email": "your_email@example.com",
    "totp_secret": "BASE32SECRET",
    "status": "active"
  }
]
EOF

# Create permissions file
chmod 600 data/accounts/accounts.json

# Setup Chrome/Chromium
echo "[*] Setting up browser support..."
apt-get install -y -qq chromium-browser chromium-driver 2>/dev/null || true

# Install system-level proxy tools
echo "[*] Installing proxy tools..."
apt-get install -y -qq tor privoxy 2>/dev/null || true

# Make main script executable
chmod +x mr_komet.py

# Create shell wrapper
cat > /usr/local/bin/komet << 'EOF'
#!/bin/bash
cd /opt/mr_komet_v3.1
python3 mr_komet.py "$@"
EOF
chmod +x /usr/local/bin/komet

# Verify installation
echo "[*] Verifying installation..."
python3 -c "import asyncio, structlog, httpx; print('[+] All core dependencies verified')"

# Display completion message
echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║            Installation Complete - MR KOMET v3.1           ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""
echo "[+] Directories created:"
echo "    - data/accounts/          (account credentials)"
echo "    - data/proxies/           (proxy lists)"
echo "    - data/fingerprints/      (generated fingerprints)"
echo "    - data/reports/           (operation reports)"
echo "    - sessions/               (session storage)"
echo "    - logs/                   (operation logs)"
echo ""
echo "[+] Sample files created:"
echo "    - operation_example.json  (copy and edit for your operation)"
echo "    - data/accounts/accounts.json (add your accounts)"
echo ""
echo "[+] Quick Start:"
echo "    1. Edit data/accounts/accounts.json with your accounts"
echo "    2. Edit operation_example.json with your target"
echo "    3. Run: python3 mr_komet.py auto --config operation_example.json"
echo ""
echo "[+] Or use interactive mode:"
echo "    python3 mr_komet.py interactive"
echo ""
echo "[+] For help:"
echo "    python3 mr_komet.py --help"
echo ""
