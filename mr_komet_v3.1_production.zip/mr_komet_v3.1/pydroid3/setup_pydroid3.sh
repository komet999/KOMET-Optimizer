#!/bin/bash
# MR KOMET v3.1 - PyDroid3 Setup
# Installation guide for PyDroid3 Python IDE on Android

echo "╔════════════════════════════════════════════════════════════╗"
echo "║       MR KOMET v3.1 - PyDroid3 Setup Instructions         ║"
echo "╚════════════════════════════════════════════════════════════╝"

echo ""
echo "[*] PyDroid3 Setup Instructions"
echo ""
echo "1. Download PyDroid3 from Google Play Store"
echo "   https://play.google.com/store/apps/details?id=ru.iiec.pydroid3"
echo ""
echo "2. Open PyDroid3 and create a new project"
echo "   Project name: mr_komet_v3.1"
echo ""
echo "3. Install pip packages via PyDroid3:"
echo "   - Open Terminal in PyDroid3"
echo "   - Run: pip install -r requirements.txt"
echo ""
echo "4. Copy MR KOMET files to PyDroid3 project directory"
echo "   - Project location: /storage/emulated/0/PyDroid3_projects/mr_komet_v3.1"
echo ""
echo "5. Create data directories:"
cat > pydroid3_init.py << 'EOF'
import os
import json
from pathlib import Path

project_dir = Path.home() / "PyDroid3_projects" / "mr_komet_v3.1"
project_dir.mkdir(parents=True, exist_ok=True)

# Create directories
dirs = [
    "data/accounts",
    "data/proxies",
    "data/fingerprints",
    "data/reports",
    "sessions",
    "logs"
]

for d in dirs:
    (project_dir / d).mkdir(parents=True, exist_ok=True)
    print(f"[+] Created {d}")

# Create sample accounts
accounts_file = project_dir / "data" / "accounts" / "accounts.json"
sample_accounts = [
    {
        "platform": "instagram",
        "username": "your_username",
        "password": "your_password",
        "email": "your_email@example.com",
        "status": "active"
    }
]

with open(accounts_file, "w") as f:
    json.dump(sample_accounts, f, indent=2)

print(f"[+] Created sample accounts file: {accounts_file}")
print("[+] Setup complete! Run mr_komet.py from PyDroid3 terminal")
EOF

echo ""
echo "6. Run initialization:"
echo "   python3 pydroid3_init.py"
echo ""
echo "7. Run MR KOMET:"
echo "   python3 mr_komet.py interactive"
echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║         PyDroid3 Setup Complete - MR KOMET v3.1           ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""
echo "[!] Note: PyDroid3 performance is limited on mobile"
echo "    Use smaller thread counts (10-20) for better results"
echo ""
