#!/bin/bash
# MR KOMET v3.1 - Termux Setup (Android)
# Optimized for Termux environment

echo "╔════════════════════════════════════════════════════════════╗"
echo "║         MR KOMET v3.1 - Termux Setup (Android)            ║"
echo "╚════════════════════════════════════════════════════════════╝"

# Update packages
echo "[*] Updating Termux packages..."
pkg update -y
pkg upgrade -y

# Install dependencies
echo "[*] Installing dependencies..."
pkg install -y python3 python-pip git curl wget openssl libssl-dev libffi-dev clang make

# Create working directory
echo "[*] Creating MR KOMET directory..."
mkdir -p ~/mr_komet_v3.1
cd ~/mr_komet_v3.1

# Create data directories
mkdir -p {data/accounts,data/proxies,data/fingerprints,data/reports,sessions,logs}

# Upgrade pip
echo "[*] Upgrading pip..."
pip install --upgrade pip setuptools --quiet

# Install requirements (with Termux-specific adjustments)
echo "[*] Installing Python packages..."
pip install -r requirements.txt --quiet

# Create Termux-specific wrapper
cat > komet_termux << 'EOF'
#!/data/data/com.termux/files/usr/bin/bash
cd $HOME/mr_komet_v3.1
python3 mr_komet.py "$@"
EOF
chmod +x komet_termux

# Create sample configuration
cat > operation_example.json << 'EOF'
{
  "platform": "instagram",
  "target_name": "target_username",
  "report_type": "impersonation",
  "report_count": 50,
  "threads": 25,
  "max_concurrent": 50,
  "detect_evasion_level": 2,
  "account_file": "data/accounts/accounts.json",
  "proxy_file": "data/proxies/working.txt"
}
EOF

# Create sample accounts file
mkdir -p data/accounts
cat > data/accounts/accounts.json << 'EOF'
[
  {
    "platform": "instagram",
    "username": "your_username",
    "password": "your_password",
    "email": "your_email@example.com",
    "status": "active"
  }
]
EOF
chmod 600 data/accounts/accounts.json

echo ""
echo "╔════════════════════════════════════════════════════════════╗"
echo "║      Termux Installation Complete - MR KOMET v3.1          ║"
echo "╚════════════════════════════════════════════════════════════╝"
echo ""
echo "[+] Installation completed in: ~/mr_komet_v3.1"
echo ""
echo "[+] Quick Start:"
echo "    1. cd ~/mr_komet_v3.1"
echo "    2. Edit data/accounts/accounts.json with your accounts"
echo "    3. Run: python3 mr_komet.py interactive"
echo ""
echo "[+] Note: Termux has reduced performance compared to Linux"
echo "    Reduce thread count if experiencing issues"
echo ""
