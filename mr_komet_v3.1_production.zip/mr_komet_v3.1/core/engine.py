#!/usr/bin/env python3
"""
MR KOMET v3.1 - Enhanced Async Engine
Async-first orchestration with circuit breaker, intelligent retry,
advanced account rotation, and detection evasion
"""

import asyncio
import time
import random
import hashlib
import json
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass, field, asdict
from enum import Enum
from datetime import datetime, timedelta
from collections import defaultdict
import structlog
from tenacity import (
    retry,
    stop_after_attempt,
    wait_exponential,
    retry_if_exception_type,
    before_sleep_log
)

logger = structlog.get_logger()

class OperationStatus(Enum):
    IDLE = "idle"
    RUNNING = "running"
    PAUSED = "paused"
    THROTTLED = "throttled"
    STOPPED = "stopped"

@dataclass
class CircuitBreakerState:
    """Circuit breaker for rate limiting and detection avoidance"""
    platform: str
    failures: int = 0
    successes: int = 0
    state: str = "closed"  # closed, open, half_open
    last_failure_time: float = 0
    opened_at: float = 0
    failure_threshold: int = 5
    success_threshold: int = 3
    timeout_seconds: int = 300
    
    def should_allow_request(self) -> bool:
        """Check if request should be allowed"""
        if self.state == "closed":
            return True
        elif self.state == "open":
            if time.time() - self.opened_at > self.timeout_seconds:
                self.state = "half_open"
                self.successes = 0
                return True
            return False
        elif self.state == "half_open":
            return True
        return False
    
    def record_success(self):
        """Record successful request"""
        self.successes += 1
        self.failures = 0
        if self.successes >= self.success_threshold and self.state == "half_open":
            self.state = "closed"
    
    def record_failure(self):
        """Record failed request"""
        self.failures += 1
        self.successes = 0
        self.last_failure_time = time.time()
        if self.failures >= self.failure_threshold:
            self.state = "open"
            self.opened_at = time.time()

@dataclass
class AccountRotationState:
    """Advanced account rotation strategy"""
    account_id: str
    platform: str
    last_used: float = 0
    usage_count: int = 0
    success_rate: float = 1.0
    failure_count: int = 0
    success_count: int = 0
    blocked: bool = False
    cooldown_until: float = 0
    risk_score: float = 0.0  # 0.0-1.0
    rotation_weight: float = 1.0
    
    def update_risk_score(self, is_success: bool, detection_intensity: int = 0):
        """Update risk score based on operation result"""
        if is_success:
            self.success_count += 1
            self.risk_score = max(0, self.risk_score - 0.05)
        else:
            self.failure_count += 1
            self.risk_score = min(1.0, self.risk_score + 0.15 + (detection_intensity * 0.1))
        
        self.rotation_weight = 1.0 / max(0.1, self.risk_score + 0.1)

@dataclass
class OperationConfig:
    """Configuration for reporting operation"""
    platform: str
    target_name: str
    report_type: str
    report_count: int = 10
    custom_message: str = ""
    images: List[str] = field(default_factory=list)
    account_file: str = ""
    proxy_file: str = ""
    threads: int = 50
    max_concurrent: int = 100
    delay_min: float = 1.0
    delay_max: float = 5.0
    exponential_backoff: bool = True
    circuit_breaker_enabled: bool = True
    fingerprint_per_thread: bool = True
    proxy_rotation_strategy: str = "random"  # random, least_used, performance
    ai_report_generation: bool = True
    detect_evasion_level: int = 3  # 1-5
    request_signature: bool = True
    target_url: str = ""
    
    def get_hash(self) -> str:
        """Get configuration hash for deduplication"""
        return hashlib.sha256(
            json.dumps(asdict(self), sort_keys=True).encode()
        ).hexdigest()

class KometEngineAsync:
    """
    Enhanced async engine with:
    - Async/await first architecture
    - Circuit breaker for rate limiting
    - Intelligent retry with exponential backoff
    - Advanced account rotation with risk scoring
    - Detection evasion strategies
    - Request fingerprinting and verification
    - Real-time monitoring and analytics
    """

    def __init__(self, logger=None, config=None):
        self.logger = logger
        self.config = config
        self.status = OperationStatus.IDLE
        self.stats = {
            "total_attempts": 0,
            "successful": 0,
            "failed": 0,
            "blocked": 0,
            "retry_count": 0,
            "by_platform": defaultdict(int),
            "by_account": defaultdict(int),
            "by_report_type": defaultdict(int),
            "start_time": None,
            "end_time": None,
            "detected_count": 0,
            "evasion_triggers": 0
        }
        self.lock = asyncio.Lock()
        self.circuit_breakers: Dict[str, CircuitBreakerState] = {}
        self.account_rotation_states: Dict[str, AccountRotationState] = {}
        self.active_tasks = set()
        self.request_cache = {}
        self.platform_engines = {}
        
    async def initialize(self):
        """Initialize all subsystems"""
        if self.logger:
            await self.logger.info("MR KOMET v3.1 ENGINE INITIALIZING")

        from modules.proxy.proxy_hunter_async import ProxyHunterAsync
        self.proxy_hunter = ProxyHunterAsync(self.config)

        from modules.fingerprint.digital_fingerprint_async import FingerprintManagerAsync
        self.fp_manager = FingerprintManagerAsync()

        from modules.auth.session_manager_async import SessionManagerAsync
        self.session_manager = SessionManagerAsync()

        from modules.ai_engine.report_ai_advanced import ReportAIAdvanced
        self.ai_engine = ReportAIAdvanced()

        from modules.report.report_generator_async import ReportGeneratorAsync
        self.report_gen = ReportGeneratorAsync()

        from modules.exploits.exploit_engine_v2 import ExploitEngineV2
        self.exploit_engine = ExploitEngineV2(self)

        if self.logger:
            await self.logger.info("All subsystems initialized successfully")

    async def load_accounts(self, filepath: str) -> List:
        """Load accounts from file"""
        accounts = await self.session_manager.load_accounts(filepath)
        
        # Initialize rotation states
        for account in accounts:
            state_key = f"{account.platform}:{account.username}"
            self.account_rotation_states[state_key] = AccountRotationState(
                account_id=state_key,
                platform=account.platform
            )
        
        return accounts

    async def load_proxies(self, filepath: str = None):
        """Load and validate proxies asynchronously"""
        if filepath:
            await self.proxy_hunter.load_from_file(filepath)
        else:
            if self.logger:
                await self.logger.info("Scraping proxies from all sources...")
            await self.proxy_hunter.scrape_proxies()

        if self.logger:
            await self.logger.info(f"Scraped {len(self.proxy_hunter.proxies)} proxies")

        working = await self.proxy_hunter.validate_all()

        if self.logger:
            await self.logger.info(f"Validated {len(working)} working proxies")
            stats = await self.proxy_hunter.get_stats()
            await self.logger.info(f"Stats: {stats}")

        return working

    def _get_next_account(self, platform_accounts: List, operation: OperationConfig) -> any:
        """Select next account using rotation strategy"""
        active = [a for a in platform_accounts if not getattr(
            self.account_rotation_states.get(f"{a.platform}:{a.username}"), 
            'blocked', False
        )]
        
        if not active:
            return None
        
        # Sort by rotation weight (risk-based)
        sorted_accounts = sorted(
            active,
            key=lambda a: self.account_rotation_states[f"{a.platform}:{a.username}"].rotation_weight,
            reverse=True
        )
        
        return sorted_accounts[0] if sorted_accounts else None

    @retry(
        stop=stop_after_attempt(3),
        wait=wait_exponential(multiplier=1, min=2, max=10),
        retry=retry_if_exception_type(Exception),
        before_sleep=before_sleep_log(logger, 20)
    )
    async def _execute_single_report(self, account, operation: OperationConfig,
                                     thread_id: str) -> Dict:
        """Execute single report with advanced error handling and evasion"""
        try:
            # Check circuit breaker
            cb = self.circuit_breakers.setdefault(
                operation.platform,
                CircuitBreakerState(platform=operation.platform)
            )
            
            if not cb.should_allow_request():
                await self.logger.warning(f"Circuit breaker OPEN for {operation.platform}")
                return {
                    "success": False,
                    "error": "CIRCUIT_BREAKER_OPEN",
                    "account": account.username,
                    "platform": operation.platform
                }
            
            # Get fingerprint
            fingerprint = await self.fp_manager.get_fingerprint(
                thread_id,
                per_thread=operation.fingerprint_per_thread
            )
            
            # Get proxy with rotation strategy
            proxy = await self.proxy_hunter.get_proxy(
                strategy=operation.proxy_rotation_strategy,
                bind_fingerprint=fingerprint.fingerprint_id
            )
            
            if not proxy:
                cb.record_failure()
                return {"success": False, "error": "NO_PROXY_AVAILABLE", "account": account.username}
            
            # Generate detection evasion headers
            headers = await self._generate_evasion_headers(
                fingerprint,
                operation.detect_evasion_level
            )
            
            # Get platform engine
            engine = await self._get_platform_engine(
                operation.platform,
                proxy,
                fingerprint,
                headers
            )
            
            if not engine:
                cb.record_failure()
                return {"success": False, "error": "ENGINE_LOAD_FAILED", "account": account.username}
            
            # Login
            login_result = await engine.login(
                account.username,
                account.password,
                account.totp_secret
            )
            
            if not login_result.get("success"):
                cb.record_failure()
                
                # Update account rotation state
                state_key = f"{account.platform}:{account.username}"
                if state_key in self.account_rotation_states:
                    state = self.account_rotation_states[state_key]
                    state.update_risk_score(False, detection_intensity=login_result.get("detection_level", 1))
                
                return {
                    "success": False,
                    "error": f"LOGIN_FAILED: {login_result.get('message')}",
                    "account": account.username,
                    "platform": operation.platform,
                    "detection_level": login_result.get("detection_level", 0)
                }
            
            # Generate AI report
            report_content = await self.ai_engine.generate_report_async(
                operation.platform,
                operation.report_type,
                operation.target_name,
                reporter_name=account.username,
                evasion_level=operation.detect_evasion_level
            )
            
            # Submit report
            result = await engine.submit_report(
                operation.target_name,
                operation.report_type,
                report_content,
                operation.images,
                headers=headers
            )
            
            # Update circuit breaker
            if result.get("success"):
                cb.record_success()
            else:
                cb.record_failure()
            
            # Update account rotation
            state_key = f"{account.platform}:{account.username}"
            if state_key in self.account_rotation_states:
                state = self.account_rotation_states[state_key]
                state.update_risk_score(
                    result.get("success", False),
                    detection_intensity=result.get("detection_level", 0)
                )
                state.usage_count += 1
                state.last_used = time.time()
            
            # Update stats
            async with self.lock:
                self.stats["total_attempts"] += 1
                if result.get("success"):
                    self.stats["successful"] += 1
                else:
                    self.stats["failed"] += 1
                
                self.stats["by_platform"][operation.platform] += 1
                self.stats["by_account"][account.username] += 1
                self.stats["by_report_type"][operation.report_type] += 1
                
                if result.get("detected"):
                    self.stats["detected_count"] += 1
                
                if result.get("evasion_triggered"):
                    self.stats["evasion_triggers"] += 1
            
            result["account"] = account.username
            result["platform"] = operation.platform
            result["report_type"] = operation.report_type
            result["proxy"] = proxy.url
            result["fingerprint"] = fingerprint.fingerprint_id[:8]
            
            await self.report_gen.add_session(result)
            
            return result

        except Exception as e:
            if self.logger:
                await self.logger.error(f"Thread {thread_id} error: {str(e)}")
            
            async with self.lock:
                self.stats["failed"] += 1
            
            return {
                "success": False,
                "error": str(e),
                "account": account.username,
                "platform": operation.platform
            }

    async def _generate_evasion_headers(self, fingerprint, evasion_level: int) -> Dict:
        """Generate detection evasion headers"""
        headers = {
            'User-Agent': fingerprint.user_agent,
            'Accept-Language': fingerprint.accept_language,
            'Accept-Encoding': 'gzip, deflate, br',
            'Cache-Control': 'max-age=0',
            'Sec-Fetch-Dest': 'document',
            'Sec-Fetch-Mode': 'navigate',
            'Sec-Fetch-Site': 'none',
            'Sec-Fetch-User': '?1',
            'Upgrade-Insecure-Requests': '1'
        }
        
        if evasion_level >= 2:
            headers.update({
                'X-Requested-With': 'XMLHttpRequest',
                'Referer': 'https://www.google.com/',
                'Origin': 'https://www.google.com'
            })
        
        if evasion_level >= 3:
            headers.update({
                'X-Forwarded-For': await self.proxy_hunter.get_random_ip(),
                'CF-Connecting-IP': await self.proxy_hunter.get_random_ip(),
                'X-Real-IP': await self.proxy_hunter.get_random_ip()
            })
        
        if evasion_level >= 4:
            headers['Cookie'] = await self._generate_cookie_string()
        
        return headers

    async def _generate_cookie_string(self) -> str:
        """Generate realistic cookie string"""
        timestamp = int(time.time() * 1000)
        return f"_ga=GA1.2.{random.randint(1000000000, 9999999999)}.{timestamp}; " \
               f"_gid=GA1.2.{random.randint(1000000000, 9999999999)}.{timestamp}"

    async def _get_platform_engine(self, platform: str, proxy, fingerprint, headers):
        """Get or create platform engine"""
        engine_key = f"{platform}_{proxy.url}"
        
        if engine_key in self.platform_engines:
            return self.platform_engines[engine_key]
        
        engines = {
            "facebook": "modules.platforms.facebook_engine_async.FacebookEngineAsync",
            "instagram": "modules.platforms.instagram_engine_async.InstagramEngineAsync",
            "twitter": "modules.platforms.twitter_engine_async.TwitterEngineAsync",
            "tiktok": "modules.platforms.tiktok_engine_async.TikTokEngineAsync",
            "youtube": "modules.platforms.youtube_engine_async.YouTubeEngineAsync",
            "snapchat": "modules.platforms.snapchat_engine_async.SnapchatEngineAsync",
        }
        
        if platform not in engines:
            return None
        
        # Dynamic import
        module_path, class_name = engines[platform].rsplit(".", 1)
        module = __import__(module_path, fromlist=[class_name])
        engine_class = getattr(module, class_name)
        
        engine = engine_class(proxy, fingerprint, self.logger, headers=headers)
        self.platform_engines[engine_key] = engine
        
        return engine

    async def execute_operation(self, operation: OperationConfig):
        """Execute full reporting operation asynchronously"""
        self.status = OperationStatus.RUNNING
        self.stats["start_time"] = time.time()

        if self.logger:
            await self.logger.banner(f"OPERATION STARTING: {operation.platform.upper()}")
            await self.logger.info(f"Target: {operation.target_name}")
            await self.logger.info(f"Reports: {operation.report_count}")
            await self.logger.info(f"Max Concurrent: {operation.max_concurrent}")

        # Load resources
        accounts = await self.load_accounts(operation.account_file)
        if not accounts:
            if self.logger:
                await self.logger.error("No accounts loaded")
            return

        platform_accounts = [a for a in accounts if a.platform == operation.platform]
        if not platform_accounts:
            if self.logger:
                await self.logger.error(f"No accounts for platform: {operation.platform}")
            return

        await self.load_proxies(operation.proxy_file)

        # Execute reports
        total_reports = min(operation.report_count, len(platform_accounts) * 20)
        
        semaphore = asyncio.Semaphore(operation.max_concurrent)
        
        async def bounded_report(i):
            async with semaphore:
                account = self._get_next_account(platform_accounts, operation)
                if not account:
                    return None
                
                thread_id = f"thread_{i % operation.max_concurrent}"
                
                # Add random delay
                delay = random.uniform(operation.delay_min, operation.delay_max)
                await asyncio.sleep(delay)
                
                return await self._execute_single_report(account, operation, thread_id)

        # Create tasks
        tasks = [bounded_report(i) for i in range(total_reports)]
        
        # Execute with progress
        results = []
        for i, coro in enumerate(asyncio.as_completed(tasks)):
            result = await coro
            if result:
                results.append(result)
                status = "SUCCESS" if result.get("success") else "FAILED"
                if self.logger:
                    await self.logger.info(
                        f"[{i+1}/{total_reports}] [{status}] - {result.get('account')}"
                    )

        self.stats["end_time"] = time.time()
        self.status = OperationStatus.IDLE

        # Generate report
        report_file = await self.report_gen.generate_html_report()

        if self.logger:
            await self.logger.banner("OPERATION COMPLETE")
            await self.logger.success(f"Total: {self.stats['total_attempts']}")
            await self.logger.success(f"Successful: {self.stats['successful']}")
            await self.logger.info(f"Failed: {self.stats['failed']}")
            await self.logger.info(
                f"Success Rate: {(self.stats['successful']/max(1, self.stats['total_attempts'])*100):.1f}%"
            )
            await self.logger.info(f"Report: {report_file}")

        return self.stats

    async def get_status(self) -> Dict:
        """Get current operation status"""
        return {
            "status": self.status.value,
            "stats": dict(self.stats),
            "circuit_breakers": {
                k: {"state": v.state, "failures": v.failures} 
                for k, v in self.circuit_breakers.items()
            },
            "active_tasks": len(self.active_tasks)
        }

    async def stop(self):
        """Stop all operations"""
        self.status = OperationStatus.STOPPED
        if self.logger:
            await self.logger.warning("Engine stop signal received")
